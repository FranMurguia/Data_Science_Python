# Graduate-Admission-Prediction
Predicted the chances of admission of a student given his/her scores information. The Dataset has been taken from Kaggle (https://www.kaggle.com/mohansacharya/graduate-admissions/home).
